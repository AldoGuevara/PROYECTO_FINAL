﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoClash
{
    public class Deck
    {
        public Deck() 
        {
            puntosVida = 0;
            daño = 0;
            nombre = "";
            ElixirMedio = 0;
        }
        private int puntosVida { get; set; }
        private int daño { get; set; }
        public string nombre { get; set; }
        private double ElixirMedio { get; set; }
        public Carta[] Cartas { get; set; }

        public void SetPuntosVida()
        {
            puntosVida = MuestraVida();
        }
        public void SetDaño()
        {
            daño = MuestraAtaque();
        }
        public void SetElixirMed()
        {
            ElixirMedio = MuestraElixir();
        }
        public double MuestraElixir()
        {
            double Elixir = 0;
            for (int i = 0; i < 8; i++)
            {
                Elixir = Elixir + Cartas[i].Elixir;
            }
            Elixir = Elixir / 8;
            return Elixir;
        }
        public int MuestraAtaque()
        {
            int Ataque = 0;
            for (int i = 0; i < 8; i++)
            {
                Ataque = Ataque + Cartas[i].Daño;
            }
            return Ataque;
        }
        public int MuestraVida()
        {
            int Vida = 0;
            for (int i = 0; i < 8; i++)
            {
                Vida = Vida + Cartas[i].PuntosVida;
            }
            return Vida;
        }
        public bool isVacia()
        {
            if (puntosVida == 0 || daño == 0 || ElixirMedio == 0)
            {
                return true;
            }
            return false;
        }
    }
}
