﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoClash
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nombre = "", equipo = "", nickname = "", ne = "", nn = "";
            int nl, ni;
            
            nombre = textBox2.Text;
            equipo = textBox1.Text;
            string[] words = equipo.Split(' ');
            foreach (string word in words)
            {
                ne += word.Substring(0, 1);
            }
            for (int i = 0; i < nombre.Length; i++)
            {
                nn += nombre.Substring(i, 1);
            }
            char fn = Convert.ToChar(nombre.Substring(0, 1));
            nl = nombre.Length - 1;
            ni = nombre.IndexOf(fn);
            nickname = ne + " - " + nn + nl + ni;

            lblNombre.Text = nombre;
            lblEquipo.Text = equipo;
            lblNick.Text = nickname;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string nombre, equipo, nickname, ne = "", nn = "";
            int nl, ni;

            nombre = textBox4.Text;
            equipo = textBox3.Text;
            string[] words = equipo.Split(' ');
            foreach (string word in words)
            {
                ne += word.Substring(0, 1);
            }
            for (int i = 0; i < nombre.Length; i++)
            {
                nn += nombre.Substring(i, 1);
            }
            char fn = Convert.ToChar(nombre.Substring(0, 1));
            nl = nombre.Length - 1;
            ni = nombre.IndexOf(fn);
            nickname = ne + " - " + nn + nl + ni;

            lblNombre2.Text = nombre;
            lblEquipo2.Text = equipo;
            lblNick2.Text = nickname;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MuestraMazos Muestra = new MuestraMazos();
            Muestra.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            IngresoManualDatos Muestra = new IngresoManualDatos();
            Muestra.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            PVP pvp = new PVP();
            pvp.Show();
        }
    }
}
