﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoClash
{
    public partial class IngresoManualDatos : Form
    {
        int cartas = 7, TDaño, TVida, TElixir;
        public IngresoManualDatos()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int daño, vida, elixir;
            daño = Convert.ToInt32(txtDanoC.Text);
            vida = Convert.ToInt32(txtVidaC.Text);
            elixir = Convert.ToInt32(txtCosteC.Text);
            lblRestante.Text = Convert.ToString(cartas);

            if (cartas != 0)
            {
                cartas += -1;
                TDaño += daño;
                TVida += vida;
                TElixir += elixir;
                
                txtDanoC.Text = null;
                txtVidaC.Text = null;
                txtCosteC.Text = null;

                MessageBox.Show("Digite los valores de la siguiente carta", "Mensaje");
            }
            else
            {
                MessageBox.Show("Mazo completo!", "Mensaje");
                cartas = 7;
                double costeM = (double)TElixir / 8;
                costeM = Math.Round(costeM,1);
                lblDanoM.Text = Convert.ToString(TDaño);
                lblVidaM.Text = Convert.ToString(TVida);
                lblCosteM.Text = Convert.ToString(TElixir);
                lblCosteMM.Text = Convert.ToString(costeM);
                TDaño = 0;
                TVida = 0;
                TElixir = 0;
            }
        }
    }
}
