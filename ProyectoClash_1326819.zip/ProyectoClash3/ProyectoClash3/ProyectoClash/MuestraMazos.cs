﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using ProyectoClash.Properties;

namespace ProyectoClash
{
    public partial class MuestraMazos : Form
    {
        public MuestraMazos()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int seleccion = comboBox1.SelectedIndex;
            if (seleccion == 0) 
            { 
                lblMazo.Text = comboBox1.SelectedItem.ToString();
                lblDañoT.Text = "2002";
                lblVidaT.Text = "4748";
                lblCosteT.Text = "21";
                lblCosteM.Text = "2.6";
                pictureBox1.Image = Properties.Resources.esqueletos;
                pictureBox1.Refresh();
                pictureBox1.Visible = true;
                pictureBox2.Image = Properties.Resources.Mosquetera;
                pictureBox2.Refresh();
                pictureBox2.Visible = true;
                pictureBox3.Image = Properties.Resources.Montapuercos;
                pictureBox3.Refresh();
                pictureBox3.Visible = true;
                pictureBox4.Image = Properties.Resources.espirituhielo;
                pictureBox4.Refresh();
                pictureBox4.Visible = true;
                pictureBox5.Image = Properties.Resources.GolemHielo;
                pictureBox5.Refresh();
                pictureBox5.Visible = true;
                pictureBox6.Image = Properties.Resources.Cannon;
                pictureBox6.Refresh();
                pictureBox6.Visible = true;
                pictureBox7.Image = Properties.Resources.BolaFuego;
                pictureBox7.Refresh();
                pictureBox7.Visible = true;
                pictureBox8.Image = Properties.Resources.tronco1;
                pictureBox8.Refresh();
                pictureBox8.Visible = true;
            }
            else if (seleccion == 1) 
            {
                lblMazo.Text = comboBox1.SelectedItem.ToString();
                lblDañoT.Text = "2061";
                lblVidaT.Text = "10411";
                lblCosteT.Text = "30";
                lblCosteM.Text = "3.8";
                pictureBox1.Image = Properties.Resources.Arqueras;
                pictureBox1.Refresh();
                pictureBox1.Visible = true;
                pictureBox2.Image = Properties.Resources.gigante;
                pictureBox2.Refresh();
                pictureBox2.Visible = true;
                pictureBox3.Image = Properties.Resources.EjercitoEsqueletos;
                pictureBox3.Refresh();
                pictureBox3.Visible = true;
                pictureBox4.Image = Properties.Resources.baby;
                pictureBox4.Refresh();
                pictureBox4.Visible = true;
                pictureBox5.Image = Properties.Resources.Principe;
                pictureBox5.Refresh();
                pictureBox5.Visible = true;
                pictureBox6.Image = Properties.Resources.minipeka;
                pictureBox6.Refresh();
                pictureBox6.Visible = true;
                pictureBox7.Image = Properties.Resources.DuendesLanza;
                pictureBox7.Refresh();
                pictureBox7.Visible = true;
                pictureBox8.Image = Properties.Resources.Mortero;
                pictureBox8.Refresh();
                pictureBox8.Visible = true;
            }
            else if (seleccion == 2)
            {
                lblMazo.Text = comboBox1.SelectedItem.ToString();
                lblDañoT.Text = "1632";
                lblVidaT.Text = "4564";
                lblCosteT.Text = "23";
                lblCosteM.Text = "2.9";
                pictureBox1.Image = Properties.Resources.Arqueras;
                pictureBox1.Refresh();
                pictureBox1.Visible = true;
                pictureBox2.Image = Properties.Resources.esqueletos;
                pictureBox2.Refresh();
                pictureBox2.Visible = true;
                pictureBox3.Image = Properties.Resources.espirituhielo;
                pictureBox3.Refresh();
                pictureBox3.Visible = true;
                pictureBox4.Image = Properties.Resources.GolemHielo;
                pictureBox4.Refresh();
                pictureBox4.Visible = true;
                pictureBox5.Image = Properties.Resources.Tesla;
                pictureBox5.Refresh();
                pictureBox5.Visible = true;
                pictureBox6.Image = Properties.Resources.Ballesta;
                pictureBox6.Refresh();
                pictureBox6.Visible = true;
                pictureBox7.Image = Properties.Resources.BolaFuego;
                pictureBox7.Refresh();
                pictureBox7.Visible = true;
                pictureBox8.Image = Properties.Resources.tronco1;
                pictureBox8.Refresh();
                pictureBox8.Visible = true;
            }
            else if (seleccion == 3)
            {
                lblMazo.Text = comboBox1.SelectedItem.ToString();
                lblDañoT.Text = "2618";
                lblVidaT.Text = "4543";
                lblCosteT.Text = "26";
                lblCosteM.Text = "3.3";
                pictureBox1.Image = Properties.Resources.caballero;
                pictureBox1.Refresh();
                pictureBox1.Visible = true;
                pictureBox2.Image = Properties.Resources.princesa;
                pictureBox2.Refresh();
                pictureBox2.Visible = true;
                pictureBox3.Image = Properties.Resources.espirituhielo;
                pictureBox3.Refresh();
                pictureBox3.Visible = true;
                pictureBox4.Image = Properties.Resources.pandila;
                pictureBox4.Refresh();
                pictureBox4.Visible = true;
                pictureBox5.Image = Properties.Resources.infernal;
                pictureBox5.Refresh();
                pictureBox5.Visible = true;
                pictureBox6.Image = Properties.Resources.cohete;
                pictureBox6.Refresh();
                pictureBox6.Visible = true;
                pictureBox7.Image = Properties.Resources.barril;
                pictureBox7.Refresh();
                pictureBox7.Visible = true;
                pictureBox8.Image = Properties.Resources.tronco1;
                pictureBox8.Refresh();
                pictureBox8.Visible = true;
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
