﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoClash
{
    public partial class PVP : Form
    {
        Deck Mazo1 = new Deck();
        Deck Mazo2 = new Deck();
        
        public PVP()
        {
            InitializeComponent();
            
        }

        private void btnBatalla_Click(object sender, EventArgs e)
        {
            if (!Mazo1.isVacia() && !Mazo2.isVacia())
            {
                if (Mazo1.MuestraAtaque() == Mazo2.MuestraAtaque() && Mazo1.MuestraVida() == Mazo2.MuestraVida())
                {
                    MessageBox.Show("Es un empate, los mazos son iguales", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                if (Mazo1.MuestraAtaque() > Mazo2.MuestraAtaque())
                {
                    MessageBox.Show("El mazo 1 gana en daño", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (Mazo1.MuestraAtaque() < Mazo2.MuestraAtaque())
                {
                    MessageBox.Show("El mazo 2 gana en daño", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }


                if (Mazo1.MuestraVida() > Mazo2.MuestraVida())
                {
                    MessageBox.Show("El mazo 1 gana en puntos de vida", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (Mazo1.MuestraVida() < Mazo2.MuestraVida())
                {
                    MessageBox.Show("El mazo 2 gana en puntos de vida", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                if (Mazo1.MuestraElixir() > Mazo2.MuestraElixir())
                {
                    MessageBox.Show("El mazo 1 tiene un mayor coste medio de elixir", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (Mazo1.MuestraElixir() < Mazo2.MuestraElixir())
                {
                    MessageBox.Show("El mazo 2 tiene un mayor coste medio de elixir", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Error, No se selecionó ningún mazo", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int seleccion = cmbboxMazo1.SelectedIndex;
            
            Carta carta1 = new Carta();
            Carta carta2 = new Carta();
            Carta carta3 = new Carta();
            Carta carta4 = new Carta();
            Carta carta5 = new Carta();
            Carta carta6 = new Carta();
            Carta carta7 = new Carta();
            Carta carta8 = new Carta();
            if (seleccion == 0)
            {
                Mazo1.nombre = "Hog 2.6 Cycle";
                carta1.Nombre = "Esqueletos";
                carta1.Daño = 81;
                carta1.PuntosVida = 81;
                carta1.Elixir = 1;

                carta2.Nombre = "Mosquetera";
                carta2.Daño = 218;
                carta2.PuntosVida = 720;
                carta2.Elixir = 4;

                carta3.Nombre = "Montapuercos";
                carta3.Daño = 318;
                carta3.PuntosVida = 1696;
                carta3.Elixir = 4;

                carta4.Nombre = "EspirituHielo";
                carta4.Daño = 110;
                carta4.PuntosVida = 230;
                carta4.Elixir = 1;

                carta5.Nombre = "GolemHielo";
                carta5.Daño = 84;
                carta5.PuntosVida = 1197;
                carta5.Elixir = 2;

                carta6.Nombre = "Cañon";
                carta6.Daño = 212;
                carta6.PuntosVida = 824;
                carta6.Elixir = 3;

                carta7.Nombre = "BolaFuego";
                carta7.Daño = 689;
                carta7.PuntosVida = 0;
                carta7.Elixir = 4;

                carta8.Nombre = "Tronco";
                carta8.Daño = 290;
                carta8.PuntosVida = 0;
                carta8.Elixir = 2;

            }
            else if (seleccion == 1)
            {
                Mazo1.nombre = "GIANT MORTAR";
                carta1.Nombre = "Arqueras";
                carta1.Daño = 107;
                carta1.PuntosVida = 304;
                carta1.Elixir = 3;

                carta2.Nombre = "Gigante";
                carta2.Daño = 254;
                carta2.PuntosVida = 4091;
                carta2.Elixir = 5;

                carta3.Nombre = "EjercitoEsqueletos";
                carta3.Daño = 81;
                carta3.PuntosVida = 81;
                carta3.Elixir = 3;

                carta4.Nombre = "BebeDragon";
                carta4.Daño = 160;
                carta4.PuntosVida = 1152;
                carta4.Elixir = 4;

                carta5.Nombre = "Principe";
                carta5.Daño = 392;
                carta5.PuntosVida = 1920;
                carta5.Elixir = 5;

                carta6.Nombre = "MiniPekka";
                carta6.Daño = 720;
                carta6.PuntosVida = 1361;
                carta6.Elixir = 4;

                carta7.Nombre = "DuendesLanza";
                carta7.Daño = 81;
                carta7.PuntosVida = 133;
                carta7.Elixir = 2;

                carta8.Nombre = "Mortero";
                carta8.Daño = 266;
                carta8.PuntosVida = 1369;
                carta8.Elixir = 4;
            }
            else if (seleccion == 2)
            {
                Mazo1.nombre = "XBOW 2.9";
                carta1.Nombre = "Arqueras";
                carta1.Daño = 107;
                carta1.PuntosVida = 304;
                carta1.Elixir = 3;

                carta2.Nombre = "Esqueletos";
                carta2.Daño = 81;
                carta2.PuntosVida = 81;
                carta2.Elixir = 1;

                carta3.Nombre = "EspirituHielo";
                carta3.Daño = 110;
                carta3.PuntosVida = 230;
                carta3.Elixir = 1;

                carta4.Nombre = "GolemHielo";
                carta4.Daño = 84;
                carta4.PuntosVida = 1197;
                carta4.Elixir = 2;

                carta5.Nombre = "Tesla";
                carta5.Daño = 230;
                carta5.PuntosVida = 1152;
                carta5.Elixir = 4;

                carta6.Nombre = "Ballesta";
                carta6.Daño = 41;
                carta6.PuntosVida = 1600;
                carta6.Elixir = 6;

                carta7.Nombre = "BolaFuego";
                carta7.Daño = 689;
                carta7.PuntosVida = 0;
                carta7.Elixir = 4;

                carta8.Nombre = "Tronco";
                carta8.Daño = 290;
                carta8.PuntosVida = 0;
                carta8.Elixir = 2;
            }
            else if (seleccion == 3)
            {
                Mazo1.nombre = "SPELL BAIT";
                carta1.Nombre = "Caballero";
                carta1.Daño = 202;
                carta1.PuntosVida = 1766;
                carta1.Elixir = 3;

                carta2.Nombre = "Princesa";
                carta2.Daño = 169;
                carta2.PuntosVida = 261;
                carta2.Elixir = 3;

                carta3.Nombre = "EspirituHielo";
                carta3.Daño = 110;
                carta3.PuntosVida = 230;
                carta3.Elixir = 1;

                carta4.Nombre = "Pandilla";
                carta4.Daño = 201;
                carta4.PuntosVida = 202;
                carta4.Elixir = 3;

                carta5.Nombre = "Infernal";
                carta5.Daño = 403;
                carta5.PuntosVida = 1749;
                carta5.Elixir = 5;

                carta6.Nombre = "Cohete";
                carta6.Daño = 1484;
                carta6.PuntosVida = 0;
                carta6.Elixir = 6;

                carta7.Nombre = "Barril";
                carta7.Daño = 120;
                carta7.PuntosVida = 202;
                carta7.Elixir = 3;

                carta8.Nombre = "Tronco";
                carta8.Daño = 290;
                carta8.PuntosVida = 0;
                carta8.Elixir = 2;
            }
            Carta[] cartas = {carta1, carta2, carta3, carta4, carta5, carta6, carta7, carta8};
            Mazo1.Cartas = cartas;
            Mazo1.SetDaño();
            Mazo1.SetPuntosVida();
            Mazo1.SetElixirMed();
            lblDanoM1.Text = Mazo1.MuestraAtaque().ToString();
            lblVidaM1.Text = Mazo1.MuestraVida().ToString();
            lblElixirM1.Text = Mazo1.MuestraElixir().ToString();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int seleccion = cmbboxMazo2.SelectedIndex;

            Carta carta1 = new Carta();
            Carta carta2 = new Carta();
            Carta carta3 = new Carta();
            Carta carta4 = new Carta();
            Carta carta5 = new Carta();
            Carta carta6 = new Carta();
            Carta carta7 = new Carta();
            Carta carta8 = new Carta();
            if (seleccion == 0)
            {
                Mazo2.nombre = "Hog 2.6 Cycle";
                carta1.Nombre = "Esqueletos";
                carta1.Daño = 81;
                carta1.PuntosVida = 81;
                carta1.Elixir = 1;

                carta2.Nombre = "Mosquetera";
                carta2.Daño = 218;
                carta2.PuntosVida = 720;
                carta2.Elixir = 4;

                carta3.Nombre = "Montapuercos";
                carta3.Daño = 318;
                carta3.PuntosVida = 1696;
                carta3.Elixir = 4;

                carta4.Nombre = "EspirituHielo";
                carta4.Daño = 110;
                carta4.PuntosVida = 230;
                carta4.Elixir = 1;

                carta5.Nombre = "GolemHielo";
                carta5.Daño = 84;
                carta5.PuntosVida = 1197;
                carta5.Elixir = 2;

                carta6.Nombre = "Cañon";
                carta6.Daño = 212;
                carta6.PuntosVida = 824;
                carta6.Elixir = 3;

                carta7.Nombre = "BolaFuego";
                carta7.Daño = 689;
                carta7.PuntosVida = 0;
                carta7.Elixir = 4;

                carta8.Nombre = "Tronco";
                carta8.Daño = 290;
                carta8.PuntosVida = 0;
                carta8.Elixir = 2;

            }
            else if (seleccion == 1)
            {
                Mazo2.nombre = "GIANT MORTAR";
                carta1.Nombre = "Arqueras";
                carta1.Daño = 107;
                carta1.PuntosVida = 304;
                carta1.Elixir = 3;

                carta2.Nombre = "Gigante";
                carta2.Daño = 254;
                carta2.PuntosVida = 4091;
                carta2.Elixir = 5;

                carta3.Nombre = "EjercitoEsqueletos";
                carta3.Daño = 81;
                carta3.PuntosVida = 81;
                carta3.Elixir = 3;

                carta4.Nombre = "BebeDragon";
                carta4.Daño = 160;
                carta4.PuntosVida = 1152;
                carta4.Elixir = 4;

                carta5.Nombre = "Principe";
                carta5.Daño = 392;
                carta5.PuntosVida = 1920;
                carta5.Elixir = 5;

                carta6.Nombre = "MiniPekka";
                carta6.Daño = 720;
                carta6.PuntosVida = 1361;
                carta6.Elixir = 4;

                carta7.Nombre = "DuendesLanza";
                carta7.Daño = 81;
                carta7.PuntosVida = 133;
                carta7.Elixir = 2;

                carta8.Nombre = "Mortero";
                carta8.Daño = 266;
                carta8.PuntosVida = 1369;
                carta8.Elixir = 4;
            }
            else if (seleccion == 2)
            {
                Mazo2.nombre = "XBOW 2.9";
                carta1.Nombre = "Arqueras";
                carta1.Daño = 107;
                carta1.PuntosVida = 304;
                carta1.Elixir = 3;

                carta2.Nombre = "Esqueletos";
                carta2.Daño = 81;
                carta2.PuntosVida = 81;
                carta2.Elixir = 1;

                carta3.Nombre = "EspirituHielo";
                carta3.Daño = 110;
                carta3.PuntosVida = 230;
                carta3.Elixir = 1;

                carta4.Nombre = "GolemHielo";
                carta4.Daño = 84;
                carta4.PuntosVida = 1197;
                carta4.Elixir = 2;

                carta5.Nombre = "Tesla";
                carta5.Daño = 230;
                carta5.PuntosVida = 1152;
                carta5.Elixir = 4;

                carta6.Nombre = "Ballesta";
                carta6.Daño = 41;
                carta6.PuntosVida = 1600;
                carta6.Elixir = 6;

                carta7.Nombre = "BolaFuego";
                carta7.Daño = 689;
                carta7.PuntosVida = 0;
                carta7.Elixir = 4;

                carta8.Nombre = "Tronco";
                carta8.Daño = 290;
                carta8.PuntosVida = 0;
                carta8.Elixir = 2;
            }
            else if (seleccion == 3)
            {
                Mazo2.nombre = "SPELL BAIT";
                carta1.Nombre = "Caballero";
                carta1.Daño = 202;
                carta1.PuntosVida = 1766;
                carta1.Elixir = 3;

                carta2.Nombre = "Princesa";
                carta2.Daño = 169;
                carta2.PuntosVida = 261;
                carta2.Elixir = 3;

                carta3.Nombre = "EspirituHielo";
                carta3.Daño = 110;
                carta3.PuntosVida = 230;
                carta3.Elixir = 1;

                carta4.Nombre = "Pandilla";
                carta4.Daño = 201;
                carta4.PuntosVida = 202;
                carta4.Elixir = 3;

                carta5.Nombre = "Infernal";
                carta5.Daño = 403;
                carta5.PuntosVida = 1749;
                carta5.Elixir = 5;

                carta6.Nombre = "Cohete";
                carta6.Daño = 1484;
                carta6.PuntosVida = 0;
                carta6.Elixir = 6;

                carta7.Nombre = "Barril";
                carta7.Daño = 120;
                carta7.PuntosVida = 202;
                carta7.Elixir = 3;

                carta8.Nombre = "Tronco";
                carta8.Daño = 290;
                carta8.PuntosVida = 0;
                carta8.Elixir = 2;
            }
            Carta[] cartas = { carta1, carta2, carta3, carta4, carta5, carta6, carta7, carta8 };
            Mazo2.Cartas = cartas;
            Mazo2.SetDaño();
            Mazo2.SetPuntosVida();
            Mazo2.SetElixirMed();
            lblDanoM2.Text = Mazo2.MuestraAtaque().ToString();
            lblVidaM2.Text = Mazo2.MuestraVida().ToString();
            lblElixirM2.Text = Mazo2.MuestraElixir().ToString();
        }
    }
}
