﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoClash
{
    public class Carta
    {
        

        public Carta()//, double elixir)
        {
            Nombre = "";
            PuntosVida = 0;
            Daño = 0;
            Elixir = 0;
        }

        public string Nombre  { get; set; }
        public int PuntosVida { get; set; }
        public int Daño { get; set; }
        public double Elixir { get; set; }

    }
}
